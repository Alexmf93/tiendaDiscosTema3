// Tus datos, tal y como los tienes. ¡Están perfectos!
const tienda = [
  {
    "titulo": "Still got the blues",
    "artista": "Gary Moore",
    "pais": "UK",
    "precio": 13.20,
    "publicacion": 1990,
    "copias": 120,
    "caratula": "https://images-na.ssl-images-amazon.com/images/I/71o6gIerHwL._SY355_.jpg"
  },
  {
    "titulo": "Recopilatorio de fados",
    "artista": "Varius artist",
    "pais": "PT",
    "precio": 20,
    "publicacion": 2024,
    "copias": 500,
    "caratula": "https://images-na.ssl-images-amazon.com/images/I/71o6gIerHwL._SY355_.jpg"
  },
  {
    "titulo": "One night only",
    "artista": "Bee Gees",
    "pais": "UK",
    "precio": 11.90,
    "copias": 200,
    "publicacion": 1998,
    "caratula": "https://is5-ssl.mzstatic.com/image/thumb/Music111/v4/fe/9c/c2/fe9cc271-e47a-28f4-c5b4-505da8d2ef10/UMG_cvrart_00731455922028_01_RGB72_1800x1800_06UMGIM54033.jpg/268x0w.jpg"
  },
  {
    "titulo": "When a man loves a women",
    "artista": "Percy Sleedge",
    "pais": "USA",
    "precio": 8.70,
    "copias": 450,
    "publicacion": 1987,
    "caratula": "https://images-na.ssl-images-amazon.com/images/I/41RST7VYA1L.jpg"
  },
  {
    "titulo": "Big Willie style",
    "artista": "Will Smith",
    "pais": "USA",
    "precio": 9.90,
    "copias": 10,
    "publicacion": 1997,
    "caratula": "https://images-na.ssl-images-amazon.com/images/I/517N7Y7xjUL._SY355_.jpg"
  },
  {
    "titulo": "La cancion de Juan Perro",
    "artista": "Radio Futura",
    "pais": "ESP",
    "precio": 12,
    "copias": 68,
    "publicacion": 1987,
    "caratula": "http://lafonoteca.net/wp-content/uploads/2008/11/Radio_Futura-La_Cancion_De_Juan_Perro-Frontal-600x600.jpg"
  },
  {
    "titulo": "The dock of the bay",
    "artista": "Otis Redding",
    "pais": "USA",
    "precio": 7.9,
    "copias": 123,
    "publicacion": 1987,
    "caratula": "https://m.media-amazon.com/images/I/715pnzys2-L._UF1000,1000_QL80_.jpg"
  },
  {
    "titulo": "The Dark Side of the Moon",
    "artista": "Pink Floyd",
    "pais": "UK",
    "precio": 10.9,
    "copias": 50,
    "publicacion": 1987,
    "caratula": "https://www.discogs.com/es/Pink-Floyd-The-Dark-Side-Of-The-Moon/master/10362"
  },
  {
    "titulo": "Kill 'em all",
    "artista": "Metallica",
    "pais": "UK",
    "precio": 15.6,
    "copias": 123,
    "publicacion": 1986,
    "caratula": "https://pbs.twimg.com/media/EdyeXaIXkAUvn9D.png"
  },
  {
    "titulo": "Un dia cualquiera",
    "artista": "Nacha Pop",
    "pais": "ESP",
    "precio": 5.9,
    "copias": 60,
    "publicacion": 2003,
    "caratula": "https://cloud10.todocoleccion.online/musica-cds/fot/2006/07/27/3157127.jpg"
  }
];

